var backgroundMode = 0;

  document.getElementsByTagName('button')[0].onclick=function() {
    if (backgroundMode == 0) {
      document.getElementById('day-night').style.backgroundColor='#000000';
      localStorage.bgcolor = '#000000';
      backgroundMode = 1;
      document.getElementById('change-background').innerHTML='Day Mode';
    } else {
      document.getElementById('day-night').style.backgroundColor='#ffffff';
      localStorage.bgcolor = '#ffffff';
      backgroundMode = 0;
      document.getElementById('change-background').innerHTML='Night Mode';
    }
  }

  //load the bgColor on page load:
  document.getElementById('day-night').style.backgroundColor=localStorage.bgcolor || '#ffffff'